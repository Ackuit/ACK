<?php

class PerchMembers_Form extends PerchAPI_Base
{
    protected $table  = 'members_forms';
    protected $pk     = 'formID';


}

?>