<?php
    // This is just a placeholder. All core files are in /core for easy updating.
    include(dirname(__FILE__).'/core/index.php');
?>