<?php
    include dirname(__FILE__).'/'.$mode.'.post.php';
?>