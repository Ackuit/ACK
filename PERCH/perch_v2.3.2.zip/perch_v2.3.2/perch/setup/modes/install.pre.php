<?php
    PerchSession::is_set('user');
?>