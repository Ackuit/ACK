DO NOT EDIT THESE TEMPLATES
===========================

These are default templates, designed to get you started. When a new version of this app is released, they will be overwritten.

To use your own templates, copy these templates into perch/templates/blog and edit them there.

So for example, if you want to edit blog/post.html, copy it to perch/templates/blog/post.html and that one will be used instead.